CREATE DATABASE dpweb1;

USE dpweb1;

--  1-4  [1] TABLA ADMINISTRADOR
CREATE TABLE  IF NOT EXISTS administrador(
id_administrador INT  NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50) NOT NULL,
apellido VARCHAR(50)NOT NULL,
correo VARCHAR(50) NOT NULL,
pass VARCHAR(500)NOT NULL,
estado CHAR(2) NOT NULL,
CONSTRAINT pk_administrador PRIMARY KEY (id_administrador)
)engine=InnoDB DEFAULT CHARSET=utf8 COLLATE=UTF8_SPANISH_CI;
-- SELECT * FROM administrador;

--  2-4  [2] TABLA CATEGORIA 
CREATE TABLE IF NOT EXISTS categoria(
id_categoria INT NOT NULL AUTO_INCREMENT,
id_administrador INT NOT NULL,
tipo_prenda VARCHAR (100) NOT NULL,
estado_categoria ENUM ('A', 'I') NOT NULL,
fecha_ingreso DATETIME NOT NULL,
CONSTRAINT pk_categoria PRIMARY KEY (id_categoria)
) engine=InnoDB DEFAULT CHARSET=utf8 COLLATE=UTF8_SPANISH_CI;
-- SELECT * FROM categoria

--  3-4  [3] TABLA TIENDA
CREATE TABLE IF NOT EXISTS tienda(
id_tienda INT AUTO_INCREMENT,
nombre_tienda VARCHAR (50),
telefono VARCHAR (30),
email VARCHAR (50),
url VARCHAR (500),
estado ENUM ('A','I'),
fecha_registro DATE,
CONSTRAINT pk_id_tienda PRIMARY KEY (id_tienda)
);
-- SELECT * FROM tienda

--  4-4  [4] TABLA PRODUCTO
CREATE TABLE IF NOT EXISTS producto(
id_producto INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
id_categoria INT NOT NULL,
id_tienda INT NOT NULL,
talla VARCHAR(15) NOT NULL,
color VARCHAR(15) NOT NULL,
genero VARCHAR(15) NULL,
precio DECIMAL(6,2) NOT NULL,
descripcion TEXT NOT NULL,
foto VARCHAR(150) NOT NULL,
estado_producto CHAR(2) NOT NULL,
URL_producto VARCHAR(1000) NOT NULL,
fecha_registro DATETIME
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- SELECT * FROM producto 



-- PA  1-4  [1] TABLA ADMINISTRADOR

-- SP agregar administrador
CREATE PROCEDURE agregar_administrador(
IN  nombre VARCHAR(50),
IN  apellido VARCHAR(50),
IN  correo VARCHAR(50),
IN  pass VARCHAR(500),
IN  estado CHAR(2) 
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
INSERT INTO administrador
VALUES(NULL,nombre,apellido,correo,pass,estado);

-- CALL agregar_administrador ('XX','AA','xa@gmail.com','123','A');

-- SP actualizar administrador
CREATE PROCEDURE actualizar_administrador(
IN  id_administrador2 INT,
IN  nombre2 VARCHAR(50),
IN  apellido2 VARCHAR(50),
IN  correo2 VARCHAR(50),
IN  pass2 VARCHAR(500),
IN  estado2 CHAR(2)
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE administrador SET nombre=nombre2,apellido=apellido2,correo=correo2,pass=pass2,estado=estado2 
WHERE id_administrador=id_administrador2;

-- CALL actualizar_administrador (1,'ZZ','EE','ze@gmail.com','456','I');

-- SP buscar administrador
CREATE PROCEDURE buscar_administrador(
IN  id_administrador2 INT
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
SELECT * FROM administrador WHERE id_administrador2 = id_administrador2;
 
-- CALL buscar_administrador(1)

 -- SP eliminar administrador
CREATE PROCEDURE eliminar_administrador(
IN  id_administrador2 INT,
IN  estado2 CHAR(2) 
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE administrador  SET estado = estado2
WHERE id_administrador = id_administrador2;
 
-- CALL eliminar_administrador (1,'A');

-- PA  2-4  [2] TABLA CATEGORIA 
-- SP agregar categoria
CREATE PROCEDURE agregar_categoria(
IN  id_administrador INT,
IN  tipo_prenda VARCHAR(100),
IN  estado_categoria ENUM('A','I'),
IN  fecha_ingreso DATETIME
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
INSERT INTO categoria
VALUES (NULL,id_administrador,tipo_prenda,estado_categoria,fecha_ingreso);

-- CALL agregar_categoria (1,'Camisa','A',NOW());

-- SP actualizar categoria

CREATE PROCEDURE actualizar_categoria(
IN  id_categoria2 INT,
IN  id_administrador2 INT,
IN  tipo_prenda2 VARCHAR(100),
IN  estado_categoria2 ENUM ('A','I'),
IN  fecha_ingreso2 DATETIME
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE categoria SET id_administrador=id_administrador2, tipo_prenda=tipo_prenda2, estado_categoria=estado_categoria2
WHERE id_categoria=id_categoria2;

-- CALL actualizar_categoria (1,1,'Camisa','A');

-- SP actualizar categoria
CREATE PROCEDURE buscar_categoria(
in id_categoria1 INT
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
SELECT * FROM categoria WHERE id_categoria=id_categoria1;

-- CALL buscar_categoria('1');

-- SP eliminar categoria
CREATE PROCEDURE eliminar_categoria(
IN  id_categoria1 INT,
IN  estado_categoria2 VARCHAR(100)
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE categoria SET estado_categoria = estado_categoria2
WHERE id_categoria=id_categoria1;

-- CALL deshabilitar_producto('1','I');

-- PA  3-4  [3] TABLA TIENDA
-- SP agregar tienda
CREATE PROCEDURE agregar_tienda(
IN nombre_tienda VARCHAR (50),
IN telefono VARCHAR (30),
IN email VARCHAR (50),
IN url VARCHAR (500),
IN estado ENUM ('A','I'),
IN fecha_registro DATE
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
INSERT INTO tienda
VALUES (NULL,nombre_tienda,telefono,email,url,estado,fecha_registro);

-- CALL agregar_tienda ('BERSHKA','0000-0000','tienda@gmai.com','www.bershka.com','A',NOW());

-- SP actualizar tienda
CREATE PROCEDURE actualizar_tienda(
IN id_tienda1 INT,
IN nombre_tienda1 VARCHAR (50),
IN telefono1 VARCHAR (30),
IN email1 VARCHAR (50),
IN url1 VARCHAR (500),
IN estado1 ENUM ('A','I')
)
NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE tienda SET nombre_tienda=nombre_tienda1, telefono=telefono1,email=email1,url=url1,estado=estado1
WHERE id_tienda=id_tienda1;

-- CALL actualizar_tienda ('1','ZARA','1111-1111','zara@gmail.com','www.zara.com','A');

-- SP buscar tienda
CREATE PROCEDURE buscar_tienda(
IN id_tienda1 INT 
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
SELECT * FROM tienda WHERE id_tienda=id_tienda1;

-- CALL buscar_tienda('1');

-- SP eliminar tienda
CREATE PROCEDURE eliminar_tienda(
IN id_tienda1 INT,
IN estado1 ENUM ('A','I')
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE tienda SET estado=estado1 
WHERE id_tienda=id_tienda1;

-- CALL eliminar_tienda ('1', 'I');

-- PA  4-4  [4] TABLA PRODUCTO
-- SP agregar producto
CREATE PROCEDURE agregar_producto(
IN  id_categoria INT,
IN  id_tienda INT,
IN  talla VARCHAR(15),
IN  color VARCHAR(15),
IN  genero VARCHAR(15),
IN  precio DECIMAL(6,2),
IN  descripcion TEXT,
IN  foto VARCHAR(150),
IN  estado_producto CHAR(2),
IN  URL_producto VARCHAR(1000),
IN  fecha_registro DATETIME
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
INSERT INTO producto
VALUES (NULL,id_categoria,id_tienda,talla,color,genero,precio,descripcion,foto,estado_producto,URL_producto,fecha_registro);

-- CALL agregar_producto (1,1,'XL','Rojo','Mujer','10.80','Vestido largo para mujer','aaa','A','aaaa',NOW());

-- SP actualizar producto
CREATE PROCEDURE actualizar_producto(
IN  id_producto2 INT,
IN  id_categoria2 INT,
IN  id_tienda2 INT,
IN  talla2 VARCHAR(15),
IN  color2 VARCHAR(15),
IN  genero2 VARCHAR(15),
IN  precio2 DECIMAL(6,2),
IN  descripcion2 TEXT,
IN  foto2 VARCHAR(150),
IN  estado_producto2 CHAR(2),
IN  URL_producto2 VARCHAR(1000),
IN  fecha_registro2 DATETIME
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE producto SET id_tienda = id_tienda2, talla = talla2, color = color2,
genero = genero2, precio = precio2, descripcion = descripcion2, foto = foto2, estado_producto = estado_producto2,
URL_producto = URL_producto2, fecha_registro = fecha_registro2 WHERE id_producto = id_producto2;

-- CALL actualizar_producto (2,2,1,'XXL','Rojo','Mujer','10.80','Vestido largo para mujer','eeeee','A','aaaa',NOW());

-- SP buscar producto

CREATE PROCEDURE buscar_producto(
in id_producto1 INT
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
SELECT * FROM producto WHERE id_producto = id_producto1;

-- CALL buscar_producto('1');

-- SP eliminar producto
CREATE PROCEDURE eliminar_producto(
IN  id_producto1 INT,
IN estado_producto2 CHAR(2)
)NOT DETERMINISTIC CONTAINS SQL SQL SECURITY
DEFINER
UPDATE producto SET estado_producto = estado_producto2 WHERE id_producto = id_producto1;


-- CALL eliminar_producto('1','I');
