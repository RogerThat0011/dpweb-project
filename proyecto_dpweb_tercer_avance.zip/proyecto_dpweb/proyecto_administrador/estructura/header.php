		<header>
		<!-- nombre de la tienda -->
		<div class="px-3 py-2 bg-dark" style="position: fixed; width: 100%;">
			<div class="container">
				 <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start as">
          			<a href="../index.html" class="d-flex my-2 my-lg-2 me-lg-auto linki">
          			T I E N D A &nbsp; O N L I N E  &nbsp; A D M I N I S T R A C I Ó N
          			</a>
          		</div>
			</div>
		</div>
		<div class="espacio"></div>
		<!-- barra de navegacion lateral -->
	</header><br><br>
	<div class="espacio"></div>
	<!-- barra lateral -->
    	<aside class="col-12 col-md-2 p-0 bg-black flex-shrink-1" id="barra-fixed" style="margin-top: 1%;">
	        <nav class="navbar navbar-expand navbar-dark bg-black flex-md-column flex-row align-items-start py-3">
	        	<br>
	            <div class="collapse navbar-collapse">
	                <ul class="flex-md-column flex-row navbar-nav w-100" id="barra-lat">
	                    <li class="nav-item" style="color: white;">
	                    	<div class="dropdown">
								<button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-home"></i> I N I C I O</button>
							  	<ul class="dropdown-menu" style="background-color: black;" aria-labelledby="dropdownMenuButton1">
							  		<li><a class="dropdown-item" href="#"> <i class="far fa-eye"></i>Ver</a></li>
								    <li><a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Agregar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-edit"></i> Editar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-trash-alt"></i> Eliminar</a></li>
							  	</ul>
							</div>
	                    </li>
	                    <br><br>
	                    <li class="nav-item">
	                    	<div class="dropdown">
								<button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-users"></i> A D M I N S</button>
							  	<ul class="dropdown-menu" style="background-color: black;" aria-labelledby="dropdownMenuButton1">
							  		<li><a class="dropdown-item" href="#"><i class="far fa-eye"></i> Ver</a></li>
								    <li><a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Agregar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-edit"></i> Editar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-trash-alt"></i> Eliminar</a></li>
							  	</ul>
							</div>
	                    </li>
	                    <br><br>
	                    <li class="nav-item">
	                    	<div class="dropdown">
								<button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-store"></i> T I E N D A S</button>
							  	<ul class="dropdown-menu" style="background-color: black;" aria-labelledby="dropdownMenuButton1">
							  		<li><a class="dropdown-item" href="#"> <i class="far fa-eye"></i>Ver</a></li>
								    <li><a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Agregar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-edit"></i> Editar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-trash-alt"></i> Eliminar</a></li>
							  	</ul>
							</div>
	                    </li>
	                    <br><br>
	                    <li class="nav-item">
	                    	<div class="dropdown">
								<button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-th-list"></i> C A T E G O R I A S</button>
							  	<ul class="dropdown-menu" style="background-color: black;" aria-labelledby="dropdownMenuButton1">
							  		<li><a class="dropdown-item" href="#"> <i class="far fa-eye"></i>Ver</a></li>
								    <li><a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Agregar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-edit"></i> Editar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-trash-alt"></i> Eliminar</a></li>
							  	</ul>
							</div>
	                    </li>
	                    <br><br>
	                    <li class="nav-item">
	                    	<div class="dropdown">
								<button class="btn btn-outline-primary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-tshirt"></i> P R O D U C T O S</button>
							  	<ul class="dropdown-menu" style="background-color: black;" aria-labelledby="dropdownMenuButton1">
							  		<li><a class="dropdown-item" href="#"> <i class="far fa-eye"></i>Ver</a></li>
								    <li><a class="dropdown-item" href="#"><i class="fas fa-plus"></i> Agregar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-edit"></i> Editar</a></li>
								    <li><a class="dropdown-item" href="#"><i class="far fa-trash-alt"></i> Eliminar</a></li>
							  	</ul>
							</div>
	                    </li>
	                </ul>
	            </div>
	        </nav>
        </aside>             

