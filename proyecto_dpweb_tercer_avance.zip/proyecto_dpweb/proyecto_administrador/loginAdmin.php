<?php

$error='';
$acceso = '';

	if (isset($_POST['submit'])) {
		
		$correo = $_POST['correo'];
		$password = $_POST['password'];
		$password2 = $_POST['confirmarPass'];

		if (!empty($correo)) {

			$correo = filter_var($correo,FILTER_SANITIZE_EMAIL);

			if (filter_var($correo,FILTER_VALIDATE_EMAIL)) {
				
				$error .= 'Por favor ingrese un correo valido <br/>';
			}
		}else{

			$error .= 'Por favor ingresa un correo <br/>';
		}

		if (!empty($password)) {
			
			if ($password != $password2) {
				
				$error.= 'Las contraseñas no coinciden <br/>';

			}else if ($password == $password2) {
				
				$acceso.='Bienvenido al administrador <br/>';
			}
		}else{

			$error.='Por favor ingrese la contraseña';
		}
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/estiloadmin.css">
	<!-- <script type="text/javascript" src="js/validacionLogin.js"></script> -->
</head>
<body>
	<div class="wrap">
		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">

			<img src="img/logo.png" class="imagenlogo">

			<input type="email" name="correo" id="correo" class="form-control" placeholder="Correo:" value="<?php if(!$acceso && isset($correo)) echo $correo ?>">

			<input type="password" name="password" id="password" class="form-control" placeholder="Contraseña:" value="<?php if(!$acceso && isset($password)) echo $password ?>">

			<input type="password" name="confirmarPass" id="password2" class="form-control" placeholder="Repita su contraseña:" value="<?php if(!$acceso && isset($password2)) echo $password2 ?>">

			<input type="submit" value="Ingresar" name="submit" class="btnIngresar" onclick="location.href='index1.php'">

			<?php if (!empty($error)): ?>

				<div class="alert error">
					<?php echo $error; ?>
				</div>

			<?php elseif($acceso):  ?>

				<div class="alert success">
					<?php  echo $acceso; ?>
				</div>

			<?php endif ?>
		</form>
	</div>

</body>
</html>