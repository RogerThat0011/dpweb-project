// function validarPassword() {
	
// 	var clave = document.getElementById("password").value;
// 	var confirmarClave = document.getElementById("password2").value;
// 	var correo = document.getElementById("correo").value;

// 	if (correo.length==0||clave.length==0||confirmarClave.lenght==0) {

// 		alert("Por favor rellene todos los campos");

// 	}else if (clave != confirmarClave) {

// 		alert("Las contraseñas no coinciden");

// 	}else if(clave == confirmarClave){

// 		alert("Bienvenido al administrador");
// 	}
// }